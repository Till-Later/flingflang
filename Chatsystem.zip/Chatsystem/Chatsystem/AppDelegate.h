//
//  AppDelegate.h
//  Chatsystem
//
//  Created by Pascal Schulze on 08.10.14.
//  Copyright (c) 2014 Pascal Schulze. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>
{
   
}

@end
