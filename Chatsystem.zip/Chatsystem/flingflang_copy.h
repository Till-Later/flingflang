#import <Foundation/Foundation.h>
@interface Controller : NSObject <NSApplicationDelegate>
{
    IBOutlet NSTextView *chatwindow;
    IBOutlet NSTextField *chattext;
    NSString *lastmessage;
    NSStatusItem *eintrag;
    IBOutlet NSMenu *menu;
    NSString *lastChatWith;
    NSString *userID;
    NSString *partnerID;
    NSArray *userArray;
    NSArray *chatTextArray;
    IBOutlet NSWindow *loginSheet;
    IBOutlet NSWindow *window;
    int lastIndex;
    NSImage *status_offline;
    NSImage *status_online;
    IBOutlet NSSecureTextField *passwordField;
    IBOutlet NSTextField *userNameField;
    IBOutlet NSButton *remember;
    
    IBOutlet NSPopUpButton *memberList;
    IBOutlet NSPanel *registrieren;
    
    IBOutlet NSTextField *registrierenName;
    IBOutlet NSTextField *registrierenMail;
    IBOutlet NSTextField *registrierenPassword;
    
}

-(IBAction)senden:(id)sender;
-(IBAction)logout:(id)sender;
-(IBAction)showLogin:(id)sender;
-(IBAction)beendeAnwendung:(id)sender;

//----------------------------------------------------------------------------------------------------------------------------------------------------


-(IBAction)login:(id)sender;
-(IBAction)zurueck:(id)sender;
-(IBAction)popUpChat:(id)sender;
-(IBAction)registrierenOpen:(id)sender;
-(IBAction)registrieren:(id)sender;

@end