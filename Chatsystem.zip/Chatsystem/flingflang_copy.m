#import "Controller.h"

@implementation Controller


//@synthesize loginSheet = _login;
//@synthesize window= _chat;
\
- (void)applicationDidFinishLaunching:
(NSNotification *)aNotification
{}


-(void)awakeFromNib{
   
    NSStatusBar *statusLeiste = [NSStatusBar systemStatusBar];
    eintrag = [statusLeiste statusItemWithLength: NSVariableStatusItemLength];
    [eintrag setMenu:menu];
    //[eintrag setTitle:@"</fling>"];
    [eintrag setHighlightMode:YES];
    
     status_offline = [NSImage imageNamed:@"flingflang_status_offline.png"];
     status_online = [NSImage imageNamed:@"flingflang_status_online.png"];
     [eintrag setImage:status_offline];
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSApplicationSupportDirectory, NSUserDomainMask, YES);
    NSString *applicationSupportDirectory = [paths firstObject];
    NSString *pfUNandPW = [NSString stringWithFormat:@"%@/.UNandPW.txt", applicationSupportDirectory];
   
   
    NSFileManager *fileManager = [NSFileManager defaultManager];
    lastIndex = 0;
    lastmessage = [NSString stringWithFormat:@""];
    
        if ([fileManager fileExistsAtPath:pfUNandPW]){
            NSString *userPw = [NSString stringWithContentsOfFile:pfUNandPW encoding:NSUTF8StringEncoding error:NULL];
            NSArray *userAndPw = [userPw componentsSeparatedByString:@"~"];
            NSString *userName = [userAndPw objectAtIndex:0];
            NSString *password = [userAndPw objectAtIndex:1];
        
        [userNameField setStringValue:userName];
            [passwordField setStringValue:password]; }
    [chatwindow setEditable:NO];
    [chatwindow setSelectable:NO];
    
    NSLog(@"%@", funktionstest(@"Hallo"));
  

}
-(IBAction)showLogin:(id)sender
{
    [NSApp activateIgnoringOtherApps:YES];
    [loginSheet makeKeyAndOrderFront:nil];
    
}

-(IBAction)logout:(id)sender
{
    [loginSheet orderFront:nil];
    [window orderOut:nil];
    [eintrag setImage:status_offline];
    if([remember state] == NSOnState){}
    else{
        [userNameField setStringValue:[NSString stringWithFormat:@""]];
        [passwordField setStringValue:[NSString stringWithFormat:@""]];
        }
    
    
}

-(IBAction)beendeAnwendung:(id)sender
{  
    [NSApp terminate:nil];
    
    
}


- (IBAction)senden:(id)sender
{
    
    NSString *texts = [chattext stringValue];
    [chatwindow setSelectable:YES];
    [chatwindow setEditable:YES];
    if([texts isEqualToString:@""] || [[memberList titleOfSelectedItem] isEqualToString:@"Chat auswählen"]){}
    else{
        [chatwindow insertText:[NSString stringWithFormat:@"%@> %@ \n",[userNameField stringValue], texts]];
       /*
        NSString *sendTextString = [NSString stringWithFormat:@"http://10.20.99.96/webprog/flingflang/php/???.php?"];   //userID, partnerID, texts
        NSURL *sendTextURL = [NSURL URLWithString:sendTextString];
        NSData *sendTextData = [NSData dataWithContentsOfURL:sendTextURL];
        NSString *sendText = [[NSString alloc] initWithData:sendTextData encoding:NSUTF8StringEncoding];
        NSLog(@"%@", sendText); */
    }
    
    [chatwindow setEditable:NO];
    [chatwindow setSelectable:NO];
    [chattext setStringValue:@""];
    
}


- (void) newMessage:(NSTimer *)timer {/*
    NSString *chatstring = [NSString stringWithFormat:@"http://10.20.99.96/webprog/flingflang/php/getChatByUserIDs.php?user=%@&user", userID];  //partnerID
    NSURL *chaturl = [NSURL URLWithString:chatstring];
    NSData *chatdata = [NSData dataWithContentsOfURL:chaturl];
    NSString *chatret = [[NSString alloc] initWithData:chatdata encoding:NSUTF8StringEncoding];
    chatTextArray = [chatret componentsSeparatedByString:@"|"];
    
    for (int i = lastIndex; i < [chatTextArray count]; i = i+2){
      
        [chatwindow setSelectable:YES];
        [chatwindow setEditable:YES];
        lastmessage = [NSString stringWithFormat:@"%@> %@ \n", [chatTextArray objectAtIndex:i], [chatTextArray objectAtIndex:i+1]];
        [chatwindow insertText:lastmessage];
        [chatwindow setEditable:NO];
        [chatwindow setSelectable:NO];
        lastIndex = i + 1;
    }
    
    
    
    
    
    
    if ([lastmessage isEqualToString: chatret]) {
    }
    else{
        if ([lastChatWith isEqualToString:@"Bitte Chat auswählen."]) {
            
        }
        else{
            [chatwindow setSelectable:YES];
            [chatwindow setEditable:YES];
            [chatwindow insertText:[NSString stringWithFormat:@"%@> %@ \n", lastChatWith, chatret]];
            lastChatWith = [memberList titleOfSelectedItem];}
            [chatwindow setEditable:NO];
            [chatwindow setSelectable:NO];
     
    }
    

    
    */
    
    
}


//----------------------------------------------------------------------------------------------------------------------------------------------------


-(IBAction)login:(id)sender{
    
     NSString *password = [passwordField stringValue];
     NSString *username = [userNameField stringValue];
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSApplicationSupportDirectory, NSUserDomainMask, YES);
    NSString *applicationSupportDirectory = [paths firstObject];
    
    if([remember state] == NSOnState){
        NSString *UNandPW = [NSString stringWithFormat:@"%@~%@", username, password];
        [UNandPW writeToFile:[NSString stringWithFormat:@"%@/.UNandPW.txt", applicationSupportDirectory] atomically:YES encoding:NSUTF8StringEncoding error:NULL];
        }
    NSLog(@"URLCHECK phase 1");
    NSError *error = nil;
    NSLog(@"URLCHECK phase 2");
    NSString *checkURLString = [NSString stringWithFormat:@"http://10.20.99.96/webprog/flingflang/php/getUserIDFromLoginData.php"];
    NSLog(@"URLCHECK phase 3");
    NSURL *checkURL = [NSURL URLWithString:checkURLString];
    NSLog(@"URLCHECK phase 4");
    NSString *checkURLError = [NSString stringWithContentsOfURL:checkURL encoding:NSUTF8StringEncoding error:&error];
   
    NSLog(@"URLCHECK phase 5");
    if ([checkURLError isEqualToString:@"nil"]) {
        NSLog(@"Error");
    }
    else{
    NSString *loginName = [userNameField stringValue];
    NSString *loginPassword = [passwordField stringValue];
    NSString *newLogin = [NSString stringWithFormat:@"http://10.20.99.96/webprog/flingflang/php/getUserIDFromLoginData.php?username=%@&password=%@", loginName, loginPassword];
    NSURL *loginBack = [NSURL URLWithString:newLogin];
    NSData *lback = [NSData dataWithContentsOfURL:loginBack];
    NSString *getLoginBack = [[NSString alloc] initWithData:lback encoding:NSUTF8StringEncoding];
    
    if([getLoginBack isEqualToString:@"error"]){
        
    }
    else {
        userID = getLoginBack;
        [loginSheet orderOut:nil];
        [window orderFront:nil];
        [memberList removeAllItems];
        [memberList addItemWithTitle:[NSString stringWithFormat:@"Chat auswählen"]];
     
        NSString *userliststring = [NSString stringWithFormat:@"http://10.20.99.96/webprog/flingflang/php/getUsers.php"];
        NSURL *userlisturl = [NSURL URLWithString:userliststring];
        NSData *userdata = [NSData dataWithContentsOfURL:userlisturl];
        NSString *userlist = [[NSString alloc] initWithData:userdata encoding:NSUTF8StringEncoding];
        userArray = [userlist componentsSeparatedByString:@"|"];
        for (int i = 1; i < [userArray count]; i = i+2){
            if ([loginName isEqualToString:[userArray objectAtIndex:i]]) {
                
            }
                 else{[memberList addItemWithTitle:[NSString stringWithFormat:@"%@", [userArray objectAtIndex:i]]];}

    }
    
    [loginSheet orderOut:nil];
    [window orderFront:nil];
    [memberList removeAllItems];
    [memberList addItemWithTitle:[NSString stringWithFormat:@"Chat auswählen"]];
     [memberList addItemWithTitle:[NSString stringWithFormat:@"Till"]];
     [memberList addItemWithTitle:[NSString stringWithFormat:@"Lennard"]];
    
    lastChatWith = [NSString stringWithFormat:@"Hallo %@. Bitte wähle einen Chat aus.", username];
    [chatwindow setString:[NSString stringWithFormat:@"%@",lastChatWith]];
    [NSTimer scheduledTimerWithTimeInterval:0.3 target:self selector:@selector(newMessage:) userInfo:nil repeats:YES];
     [eintrag setImage:status_online];
    }

    }
}
    


-(IBAction)popUpChat:(id)sender{
    
       if([lastChatWith isEqualToString: [memberList titleOfSelectedItem]]){
     

       }
        else{
            [chatwindow setString:[NSString stringWithFormat:@""]];
             lastChatWith = [memberList titleOfSelectedItem];
            
            
            for (int i = 1; i < [userArray count]; i = i+2){
                if ([lastChatWith isEqualToString:[userArray objectAtIndex:i]]) {
                    partnerID = [NSString stringWithFormat:@"%i", i-1 ];
                    lastIndex = 0;
                    lastmessage = [NSString stringWithFormat:@""];
                
                   
                }
            }

        
        }
    if ([memberList indexOfItemWithTitle:@"Chat auswählen"] == 0) {
        [memberList removeItemAtIndex:0];
        }

}

-(IBAction)registrierenOpen:(id)sender{
    
    [NSApp beginSheet:registrieren
    modalForWindow:loginSheet
    modalDelegate:self
    didEndSelector:@selector(nachEnde:)
    contextInfo:nil];
    [NSApp runModalForWindow:registrieren];
    [NSApp endSheet:registrieren];
    [registrieren orderOut:nil];
    
    
    
}

-(IBAction)registrieren:(id)sender{
    NSString *newName = [registrierenName stringValue];
    NSString *newMail = [registrierenMail stringValue];
    NSString *newPassword = [registrierenPassword stringValue];
     NSString *newRegister = [NSString stringWithFormat:@"http://10.20.112.119/webprog/flingflang/php/createNewUser.php?username=%@&password=%@&email=%@", newName, newPassword, newMail];
    NSURL *registrierenBack = [NSURL URLWithString:newRegister];
    NSData *back = [NSData dataWithContentsOfURL:registrierenBack];
    NSString *getBack = [[NSString alloc] initWithData:back encoding:NSUTF8StringEncoding];

    
    if([getBack isEqualToString:@"Hat geklappt!"]){
    [NSApp stopModal];
    }
    else{}
}

-(void)nachEnde:(id)sender
{
   
}

-(IBAction)zurueck:(id)sender{[NSApp stopModal];}

@end